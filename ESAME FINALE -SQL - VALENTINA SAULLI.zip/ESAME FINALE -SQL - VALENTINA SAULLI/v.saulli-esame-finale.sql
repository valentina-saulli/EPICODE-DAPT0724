-- task 2

DROP SCHEMA IF EXISTS ToysGroup_database;

CREATE SCHEMA ToysGroup_database;

USE ToysGroup_database;

CREATE TABLE category_tgroup (
category_id INT PRIMARY KEY AUTO_INCREMENT
, namecategory VARCHAR (50)
);


CREATE TABLE product_tgroup (
product_id INT PRIMARY KEY AUTO_INCREMENT
, productname VARCHAR(50)
, category_id INT
, listprice DECIMAL(10,2)
, color VARCHAR (25)
, userage INT
, startdate date
, CONSTRAINT FK_CATEGORY FOREIGN KEY (CATEGORY_ID) REFERENCES category_tgroup (category_id)
);

CREATE TABLE Region (
 region_id INT PRIMARY KEY AUTO_INCREMENT
 , nameregion VARCHAR (50)
 );


CREATE TABLE sales_tgroup (
order_id INT 
, orderlinenumber_id INT
, product_id INT
, orderdate date 
, duedate date
, shipdate date
, region_id INT
, orderquantity DECIMAL (4,2)
, uniteprice DECIMAL (10,2)
, salesamount DECIMAL (10,2)
, CONSTRAINT PK_SCONTRINO PRIMARY KEY (ORDER_ID, ORDERLINENUMBER_ID)
, CONSTRAINT FK_PRODOTTO foreign key (PRODUCT_ID) REFERENCES product_tgroup (PRODUCT_ID)
, CONSTRAINT FK_REGION FOREIGN KEY (REGION_ID) REFERENCES REGION (REGION_ID)
);
 
 
 
 CREATE TABLE State (
 state_id INT PRIMARY KEY AUTO_INCREMENT
 , namestate VARCHAR (50)
 , Region_id INT
 , CONSTRAINT FK_STATO FOREIGN KEY (REGION_ID) REFERENCES REGION (REGION_ID)
 );

-- task 3

INSERT INTO category_tgroup (namecategory)
VALUES 
    ('Aria'),
    ('Musica'),
    ('Casa'),
    ('Edilizia');
    commit;
    
    
    SELECT
    *
    FROM
    category_tgroup;
    
    INSERT INTO product_tgroup (productname, category_id, listprice, color, userage, startdate)
VALUES
    ('Palla', 1, 699.99, 'Black', 3, '2023-01-01'),
    ('frisbie', 1, 19.99, 'Blue', 2, '2023-01-10'),
    ('Batteria', 2, 14.99, 'N/A', 4, '2023-01-15'),
    ('Tamburo', 2, 699.99, 'Black', 3, '2023-01-01'),
    ('Costruzioni', 4, 19.99, 'Blue', 1, '2022-01-10'),
    ('Pianoforte', 2, 14.99, 'N/A', 10, '2021-01-15'),
    ('Sedia', 3, 49.99, 'Multi-color', 5, '2024-01-20');


 SELECT
 *
 FROM
 product_tgroup;
 
 INSERT INTO Region (nameregion)
VALUES 
    ('North America'),
    ('Europe'),
    ('Asia'),
    ('Australia');
    
    SELECT
    *
    FROM
    Region;
    
    INSERT INTO State (namestate, Region_id)
VALUES
    ('California', 1),
    ('Texas', 1),
    ('Bavaria', 2),
    ('Tokyo', 3);
    
    INSERT INTO sales_tgroup (order_id, orderlinenumber_id, product_id, orderdate, duedate, shipdate, region_id, orderquantity, uniteprice, salesamount)
VALUES
    (1, 1, 1, '2024-02-01', '2024-02-05', '2024-02-03', 1, 2, 699.99, 1399.98),
    (1, 2, 2, '2023-02-10', '2024-02-15', '2024-02-12', 2, 5, 19.99, 99.95),
    (3, 1, 3, '2022-02-20', '2024-02-25', '2024-02-22', 3, 3, 14.99, 44.97),
    (4, 1, 4, '2023-02-28', '2024-03-05', '2024-03-03', 4, 1, 49.99, 49.99),
    (5, 1, 7, '2021-02-01', '2024-02-05', '2024-02-03', 1, 2, 699.99, 1399.98),
    (5, 2, 6, '2025-02-10', '2024-02-15', '2024-02-12', 2, 5, 19.99, 99.95);

SELECT
*
FROM
sales_tgroup;

COMMIT;

-- TASK 4

-- domanda 1

SELECT DISTINCT category_id, count(*) FROM category_tgroup GROUP BY category_id;

SELECT DISTINCT product_id, count(*) FROM product_tgroup group by product_id;

SELECT order_id, orderlinenumber_id, COUNT(*) AS conteggio FROM sales_tgroup GROUP BY order_id, orderlinenumber_id HAVING COUNT(*) > 1;

SELECT DISTINCT REGION_ID, count(*) FROM REGION group by REGION_ID;

SELECT DISTINCT state_id, count(*) FROM state group by state_id;

-- domanda 2

SELECT 
ORDER_ID
, ORDERDATE
, p.productname
, c.namecategory
, r.nameregion
, t.namestate
, DATEDIFF (SHIPDATE, CURDATE())
, DATEDIFF(CURDATE(), ORDERDATE) > 180 AS piùdi180giorni
FROM
sales_tgroup as s
inner join
product_tgroup  as p
on
s.product_id = p.product_id
inner join
category_tgroup as c
on 
p.category_id = c.category_id
inner join
Region as r
on 
r.region_id = s.region_id
inner join
state as t
on
t.region_id = r.region_id
;

-- domanda 3

SELECT 
    product_id AS codice_prodotto,
    SUM(orderquantity) AS totale_venduto
FROM 
    sales_tgroup
WHERE 
    YEAR(ORDERDATE) = (SELECT MAX(YEAR(ORDERDATE)) FROM sales_tgroup)
GROUP BY 
    product_id
HAVING 
    SUM(orderquantity) > (SELECT AVG(totale_venduto)
                     FROM (SELECT 
                               SUM(orderquantity) AS totale_venduto
                           FROM 
                               sales_tgroup
                           WHERE 
                               YEAR(ORDERDATE) = (SELECT MAX(YEAR(ORDERDATE)) FROM sales_tgroup)
                           GROUP BY 
                               product_id) AS subquery);



-- domanda 4
SELECT
P.PRODUCT_ID
, YEAR(S.orderdate) AS ANNO
, P.PRODUCTNAME
, SUM(S.SALESAMOUNT)
FROM
sales_tgroup AS S 
INNER JOIN 
PRODUCT_TGROUP AS P
ON 
P.PRODUCT_ID = S.PRODUCT_ID
GROUP BY YEAR(ORDERDATE)
, P.PRODUCT_ID
, P.PRODUCTNAME;

-- domanda 5

SELECT
SUM(SALESAMOUNT)
, t.namestate
, YEAR (ORDERDATE) as anno
FROM
sales_tgroup as s
inner join 
region as r
on 
r.region_id = s.region_id
inner join 
state as t
on 
t.Region_id = r.region_id
group by
t.namestate
, year(orderdate)
order by
year(orderdate) desc
, 1 desc; 


-- domanda 6
SELECT
    p.category_id,
    c.namecategory,
    COUNT(c.namecategory) AS categorierichieste
FROM
    product_tgroup AS p
    INNER JOIN 
    category_tgroup AS c 
    ON 
    p.category_id = c.category_id
GROUP BY 
    c.namecategory, p.category_id;
    
    -- domanda 7

SELECT 
    p.product_id,
    p.productname
FROM 
    product_tgroup AS p
    LEFT JOIN 
    sales_tgroup AS s 
    ON 
    p.product_id = s.product_id
WHERE 
    s.product_id IS NULL;
    
  SELECT 
    product_id,
    productname
FROM 
    product_tgroup
WHERE 
    product_id NOT IN (SELECT DISTINCT product_id FROM sales_tgroup);
  

-- domanda 8
CREATE VIEW Vw_Prodotti
AS (
SELECT
	p.product_id,
    p.productname,
	c.namecategory    
FROM
	product_tgroup as p
INNER JOIN
	category_tgroup as c
ON
	p.category_id = c.category_id
);

-- domanda 9

CREATE VIEW Vw_geografica
AS (
SELECT
	nameregion,
    namestate
FROM
	region as r
INNER JOIN
	state as s
ON
	r.region_id = s.region_id
);



 